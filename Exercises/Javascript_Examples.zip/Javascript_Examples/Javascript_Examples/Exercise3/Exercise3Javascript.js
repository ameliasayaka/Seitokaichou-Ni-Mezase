var isLightOn = false;
var totalNum;
function ToggleLight()
{
	if (isLightOn === false)
	{
		document.getElementById('lightBulb').src="img/bulb-on.png";
		isLightOn = true;
	}
	else {
		{
			document.getElementById('lightBulb').src="img/bulb-off.png";
			isLightOn = false;
		}
	}
}

function AddNumbers(numA,numB)
{
	totalNum = numA + numB;
	document.getElementById('numbers').innerHTML=totalNum;
}

function AlertMessage()
{
  alert('You have been alerted!');
}


function ConsoleMessage()
{

  console.log('Console is active');


}


function WhatsMyName()
{
  var firstName = "Amelia";
  var lastName = "Cutler";

  console.log(firstName + " " + lastName);
}

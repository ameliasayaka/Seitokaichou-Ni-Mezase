var playerName;
var playerColour;
var playerHealth;
var weaponValue;

function CreatePlayer()
{
 playerName = document.getElementById('playername').value;
 document.getElementById('name').innerHTML=playerName;

 playerColour = document.getElementById('playercolour').value;
 document.getElementById('colour').style.backgroundColor=playerColour;

 playerHealth = document.getElementById('playerhealth').value;
 document.getElementById('health').innerHTML=playerHealth;

 weaponValue = document.getElementById('playerweapon').value;

switch(parseInt(weaponValue))
{
 case 1:
   document.getElementById('weapon').innerHTML="Crossbow of much hurting";
   break;
 case 2:
   document.getElementById('weapon').innerHTML="Broadsword of so slicing";
   break;
 case 3:
   document.getElementById('weapon').innerHTML="Wand of amaze magics";

}
}
